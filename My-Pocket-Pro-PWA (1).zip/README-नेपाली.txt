My Pocket Pro — PWABuilder बाट APK बनाउने तरिका
=================================================

यो फोल्डर PWA का रूपमा तयार छ (manifest, service worker, icons, offline सहित)।
PWABuilder ले APK बनाउन एपको सार्वजनिक HTTPS लिङ्क (URL) चाहिन्छ, त्यसैले पहिले होस्ट गर्नुपर्छ।

चरण १ — Hosting (निःशुल्क)
  • https://app.netlify.com/drop खोल्नुहोस् र यो फोल्डर (ZIP खोलेपछि) drag-and-drop गर्नुहोस्।
    (वा GitHub Pages / Cloudflare Pages प्रयोग गर्न सक्नुहुन्छ।)
  • तपाईंले https://xxxxx.netlify.app जस्तो लिङ्क पाउनुहुन्छ। ब्राउजरमा खोलेर एप चल्छ कि हेर्नुहोस्।

चरण २ — PWABuilder
  • https://www.pwabuilder.com खोल्नुहोस्, माथिको लिङ्क हालेर Start थिच्नुहोस्।
  • Manifest र Service Worker दुवै हरियो (✓) देखिनुपर्छ।
  • "Package for stores" → Android → Options:
      Package ID : com.mypocket.pro   (आफ्नो नाम अनुसार फेर्न सक्नुहुन्छ, पछि फेर्न मिल्दैन)
      App name   : My Pocket Pro
      Signing key: "New" छान्नुहोस्
  • Generate थिच्नुहोस् → ZIP डाउनलोड हुन्छ (भित्र .apk, .aab, signing.keystore, assetlinks.json हुन्छ)।

चरण ३ — Address bar हटाउन (महत्त्वपूर्ण)
  • ZIP भित्रको assetlinks.json लाई यो फोल्डरमा  .well-known/assetlinks.json  मा राख्नुहोस्
    र फोल्डर फेरि Netlify मा deploy गर्नुहोस्।
  • नगरे APK मा माथि ब्राउजरको URL पट्टी देखिन्छ।

चरण ४ — Install
  • .apk फाइल फोनमा पठाएर खोल्नुहोस् ("Unknown sources" अनुमति दिनुपर्ने हुन सक्छ)।
  • Play Store को लागि .aab फाइल प्रयोग गर्नुहोस्।
  • signing.keystore र त्यसको password सुरक्षित राख्नुहोस् — पछि अपडेट गर्न चाहिन्छ।

डाटाबारे सूचना
  • एपको डाटा (localStorage) URL अनुसार छुट्टै हुन्छ। पहिले अर्को ठाउँ/ब्राउजरमा राखेको डाटा
    नयाँ APK मा स्वतः आउँदैन। पुरानो एपको Settings बाट Backup लिनुहोस् र नयाँमा Restore गर्नुहोस्।
  • फोनको Chrome को "Clear data" गर्दा APK को डाटा पनि मेटिन सक्छ — नियमित Backup लिनुहोस्।

पछि फाइल बदल्दा
  • sw.js भित्रको VERSION (mpp-v1) लाई mpp-v2, mpp-v3 ... बनाउनुहोस् ताकि प्रयोगकर्ताले अपडेट पाऊन्।
